
export const API_BASE_URL = 'https://www.server.shedloadoverseas.com';

export const USER_DATA_KEY = 'swifttrack_user_data';
// Removed AUTH_TOKEN_KEY, ADMIN_AUTH_TOKEN_KEY, ADMIN_USER_DATA_KEY
