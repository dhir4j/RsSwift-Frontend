import { AdminDashboardContent } from '@/components/admin/admin-dashboard-content';

export default function AdminDashboardPage() {
  return (
    <div className="space-y-6">
      <AdminDashboardContent />
    </div>
  );
}
