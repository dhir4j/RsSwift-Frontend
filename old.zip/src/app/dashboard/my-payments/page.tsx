
import { MyPaymentsTable } from '@/components/payment/my-payments-table';

export default function MyPaymentsPage() {
  return (
    <div>
      <MyPaymentsTable />
    </div>
  );
}
