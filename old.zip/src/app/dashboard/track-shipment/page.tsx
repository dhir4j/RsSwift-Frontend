import { TrackShipmentForm } from '@/components/shipment/track-shipment-form';

export default function TrackShipmentPage() {
  return (
    <div>
      <TrackShipmentForm />
    </div>
  );
}
