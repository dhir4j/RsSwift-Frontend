import { PricingCalculator } from '@/components/pricing/pricing-calculator';

export default function PricingPage() {
  return (
    <div>
      <PricingCalculator />
    </div>
  );
}
