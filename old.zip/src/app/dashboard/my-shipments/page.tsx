import { MyShipmentsTable } from '@/components/shipment/my-shipments-table';

export default function MyShipmentsPage() {
  return (
    <div>
      <MyShipmentsTable />
    </div>
  );
}
